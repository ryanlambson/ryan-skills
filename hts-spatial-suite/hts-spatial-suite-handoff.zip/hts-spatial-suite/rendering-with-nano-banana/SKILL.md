---
name: rendering-with-nano-banana
description: >
  Renders a prepared SketchUp line-work view into a photorealistic image via Higgsfield
  Nano Banana, image-to-image. Use when Ryan says "render this in Nano Banana", "make this
  photorealistic", "generate the client visual", or "render this view". Chooses a tier
  (nano_banana_2 to iterate, nano_banana_pro for the final 4K), uploads the export as the
  conditioning image, and drives the Universal Prompt formula with layout-lock phrasing so
  the geometry is preserved. Falls back to manual Gemini Nano Banana if Higgsfield is
  unavailable. Do NOT use for modeling or for spec-grade output.
metadata:
  author: Ryan Lambson (HTS / Green Holmes)
  version: 0.1.0-skeleton
  standard: agent-skills-1.0
  status: SKELETON — Phase 4 Draft pending
---

# Spatial Render

> SKELETON. Stubs define drafted content.

One-paragraph purpose: take the line-work export to a sell-the-idea photoreal render while
keeping the layout the model defines.

## Tier choice
[Stub] `nano_banana_2` for fast iteration with the client; `nano_banana_pro` for the final
high-fidelity 4K. Both image-to-image, up to 4K.

## Image-to-image handoff
[Stub] Upload the export (Higgsfield media_upload) and pass as the `image` role to
generate_image. Always condition on the image; never pure text-to-image for a known plan.
Fallback: manual Gemini Nano Banana with the same prompt + image.

## Universal Prompt formula
[Stub] Four anchors — Material palette · Site/context · Lighting/atmosphere · Narrative —
plus layout-lock phrasing: "keep the exact layout proportions and relationships",
"don't guess on the material set, look at my lines". Full scaffold in
knowledge/materials-semantic-template.md.

## Iteration hygiene
[Stub] If a material renders wrong repeatedly, start a fresh thread (clears bad memory) or
add the material detail to the main prompt. Change one variable at a time.

## Examples + troubleshooting
[Stub] (1) iterate materials on nano_banana_2; (2) final 4K on nano_banana_pro.
Hallucinated geometry → strengthen line overlay / add layout-lock phrasing.
