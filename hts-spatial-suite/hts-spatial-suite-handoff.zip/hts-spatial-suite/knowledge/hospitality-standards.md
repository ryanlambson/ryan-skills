# Hospitality Standards (shared knowledge)

> Jurisdiction-swappable DEFAULTS for modeling. These are sane starting dimensions to make
> a model look right — they are NOT certified compliance values. Spec-grade verification is
> the v2 `spatial-compliance` skill. Select the block matching the job's market.
>
> STATUS: starter. Figures marked [VERIFY] need confirming against the primary source
> before relying on them; several values in the source research doc did not extract cleanly.

## How to use
1. Read the job's jurisdiction (US or AU). Default AU for HTS work unless told otherwise.
2. Pull clearances/room areas as modeling defaults only.
3. Never present these as compliance guarantees in client materials.

---

## US block — ADA / IBC (imperial)

Confident defaults:
- Clear door opening width: 32 in min (ADA 404).
- Wheelchair turning space: 60 in diameter, or T-shaped (ADA 304).
- Ramp slope (new build): 1:12 max (ADA 405).

[VERIFY] hotel room areas by tier; bath allocation; dining area per seat; table-to-table
spacing; service aisle width; buffet counter width; reach ranges; counter heights; water
closet clearances. (Source: research doc ADA table — re-pull exact figures.)

## AU block — NCC / BCA + AS 1428.1 (metric)

Starter defaults [VERIFY all against AS 1428.1 + current NCC]:
- Clear door opening width: 850 mm min (AS 1428.1).
- Wheelchair turning circle: 1540 mm diameter / 1540 x 2070 turning space.
- Ramp slope: 1:14 max (AS 1428.1), with landings.
- Circulation/path clear width: 1000 mm min.

[VERIFY] hotel room areas by brand tier (metric); bathroom allocation; dining area per
seat; table spacing; service aisle; buffet counter; bench/counter heights; sanitary
compartment clearances.

---

## Dining / public zones (jurisdiction-light, modeling defaults)
[VERIFY/fill] area per seat; table-to-table spacing; service aisle width; buffet width.

## Hospitality tag structure (AIA-style starting point)
- A-WALL-INTR (interior walls), A-WALL-EXTR (exterior), A-FLOR (floors), A-DOOR, A-GLAZ
  (glazing/windows), A-FURN (furniture), A-FFE (fixtures/equipment), A-CLNG (ceiling).
- Tags go on groups/components; raw geometry stays Untagged.
