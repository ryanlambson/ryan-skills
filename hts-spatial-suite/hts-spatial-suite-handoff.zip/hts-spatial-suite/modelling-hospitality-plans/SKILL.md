---
name: modelling-hospitality-plans
description: >
  Builds a 3D SketchUp model of a hospitality space from a 2D floor plan, via the Trimble
  SketchUp MCP. Use when Ryan says "model this plan in SketchUp", "build the 3D from this
  DWG/DXF", "extrude these walls", or "turn this floor plan into a model". Imports the plan,
  uses the Trimble baseline skills for cleansing and solid validation, extrudes walls, and
  places doors and windows by CONSTRUCTION (the Trimble MCP has no native boolean
  operations, so no subtract()). Applies a hospitality tag structure and adaptive segment
  counts for curves. Do NOT use for rendering (see rendering-with-nano-banana) or for spec-grade
  compliance modeling.
metadata:
  author: Ryan Lambson (HTS / Green Holmes)
  version: 0.1.0-skeleton
  standard: agent-skills-1.0
  status: SKELETON — Phase 4 Draft pending
---

# Spatial Plan-to-Model

> SKELETON. Stubs define drafted content.

One-paragraph purpose: convert a cleaned 2D hospitality plan into a tagged, watertight 3D
model ready for render-prep.

## Input formats and the two lanes
[Stub] Accurate-model lane: DWG/DXF/SKP. Express lane: sketch/viewport (skip to render).
Raster-only inputs route to the express lane, not precise modeling.

## Construction rules (critical)
[Stub]
- NO booleans: build wall segments framing each opening; never subtract a cutter.
- Ground-plane normal: reverse faces whose normal points down before push-pull.
- Active-context nesting: geometry into a group/component, never the model root.
- Hospitality tag structure (AIA-style) on groups/components; raw geometry untagged.
- Adaptive segment count scaled to radius for curved elements.

## Lean-on map (do not rebuild)
[Stub] `sketchup-clean-geometry` → cleansing; `sketchup-solid-cleanup` → watertight check;
`sketchup-part-boundaries` → rough openings/abutment; `sketchup-components` → repeated items.

## Example
[Stub] Import DWG → trace/extrude walls to ceiling height → frame a 36" doorway by
construction → tag → validate solid.

## Troubleshooting
[Stub] Non-manifold groups; inverted extrusion; wrong import scale; openings not closing.
