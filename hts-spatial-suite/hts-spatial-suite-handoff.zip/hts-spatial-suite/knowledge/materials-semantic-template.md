# Materials & Semantic Template (shared knowledge)

Two jobs in one file:
1. A SketchUp material/colour palette applied before export, acting as a SEMANTIC MAP that
   tells Nano Banana what each surface is.
2. The Universal Prompt scaffold that drives `rendering-with-nano-banana`.

> STATUS: starter. Expand the palette and add worked prompt examples at Draft.

---

## 1. Semantic colour → material map

Apply a simple, flat base colour/low-res texture per surface in SketchUp. The colour is a
tag the render engine reads; it then renders the real material. Keep it readable, not clay.

| Surface role | SketchUp base cue | Renders as (prompt support) |
|---|---|---|
| Timber floor | warm brown, subtle grain | herringbone / plank oak, satin finish |
| Stone/feature wall | mid grey, slight texture | honed stone or microcement |
| Glazing | pale blue, transparent | clear glass, accurate reflections |
| Joinery / cabinetry | distinct mid tone, colour-by-material edges | matte timber veneer, fine reveals |
| Soft furnishing | muted accent colour | velvet / boucle upholstery |
| Metal trim | cool grey | brushed brass or black steel |

Principle from the videos: don't make the engine guess — the base colour plus the prompt's
material palette together lock the look.

---

## 2. Universal Prompt scaffold

Anchor the AI by answering four categories every time, then add the layout lock.

1. MATERIAL PALETTE — exact finishes ("smooth white plaster", "polished herringbone oak",
   "brushed brass", "grey velvet").
2. SITE / CONTEXT — location and surroundings ("rooftop bar overlooking the Swan River").
3. LIGHTING / ATMOSPHERE — time/mood ("golden-hour afternoon, warm 2800K accent lamps").
4. NARRATIVE / STORY — how the space is used ("guests at the bar, soft evening buzz").

Layout-lock lines (always include for a known plan):
- "Preserve the exact spatial layout, wall boundaries, and camera perspective of the
  reference image."
- "Don't guess on the material set — look at my lines."
- (Plan-to-iso variant) "Convert my plan into a 60-degree 3D isometric view while keeping
  the exact layout proportions and relationships."

### Skeleton template
> A professional interior photograph of a [VENUE TYPE]. [MATERIAL PALETTE]. [SITE/CONTEXT].
> [LIGHTING/ATMOSPHERE]. [NARRATIVE]. Render in 4K, photorealistic. Preserve the exact
> spatial layout, wall boundaries, and camera perspective of the reference image; don't
> guess on materials, look at my lines.

[Draft TODO] Add 2-3 fully worked examples (guest suite, restaurant, rooftop bar) and a
matching `assemble_prompt.py` mapping.
