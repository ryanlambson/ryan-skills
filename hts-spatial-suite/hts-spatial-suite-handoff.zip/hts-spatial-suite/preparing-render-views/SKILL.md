---
name: preparing-render-views
description: >
  Prepares a SketchUp model for Nano Banana rendering by producing a clean line-work view,
  not a bare clay render. Use when Ryan says "set up the view for rendering", "export a
  clean line view", "get this ready for Nano Banana", or "prep the render view". Applies a
  construction-drawing / outline style, ambient occlusion for grounding, alpha-plane fixes,
  a framed camera, and optional multi-scene views, then exports a flat PNG/JPG that locks
  the perspective. Leans on the Trimble baseline skills sketchup-styles, sketchup-camera,
  and sketchup-scenes. Do NOT use for the modeling step or the render call itself.
metadata:
  author: Ryan Lambson (HTS / Green Holmes)
  version: 0.1.0-skeleton
  standard: agent-skills-1.0
  status: SKELETON — Phase 4 Draft pending
---

# Spatial Render-Prep

> SKELETON. Stubs define drafted content.

One-paragraph purpose: turn a finished model into the line-work export that makes Nano
Banana faithful to the real geometry.

## The line-work principle (why)
[Stub] Bare grayscale clay makes Nano Banana hallucinate (phantom pools, wrong doors,
flattened one-point perspective). Clean outline / construction-drawing line work locks the
vanishing points and structure. Target clean outline edges + semantic colour, not dense
wireframe and not clay.

## Style / edge / AO / alpha settings
[Stub] Use the Trimble "construction drawing look" / clean style; edges as crisp outline or
colour-by-material (avoid dense black edges); AO on to ground furniture; disable AO + shadow
casting on transparent alpha planes.

## Camera and multi-scene views
[Stub] Frame a hero camera; add scenes for a render set (multiple angles) via sketchup-scenes.

## Export
[Stub] Flat PNG/JPG from the viewport; note resolution/aspect to match the render tier.

## Example + troubleshooting
[Stub] Export hero line view; fix muddy edges; fix floating furniture (AO).
