---
name: visualising-hospitality-spaces
description: >
  Master orchestrator for the hts-spatial-suite. Use whenever Ryan wants to turn a
  hospitality floor plan into a client-facing visualisation end to end — phrases like
  "turn this floor plan into a render", "visualise this venue to show the client",
  "take this DWG to a photoreal image", or "run the spatial pipeline". Routes the job
  through four stages (intake, model, render-prep, render) and hands off to the component
  skills modelling-hospitality-plans, preparing-render-views, and rendering-with-nano-banana. Loads the Trimble
  SketchUp MCP baseline skills first. Do NOT use for spec-grade or compliance-certified
  drawings, or for liquor-licensing PIA spatial work (that stays in hts-lla-suite).
metadata:
  author: Ryan Lambson (HTS / Green Holmes)
  version: 0.1.0-skeleton
  standard: agent-skills-1.0
  status: SKELETON — Phase 4 Draft pending
---

# Spatial Pipeline — Orchestrator

> SKELETON. Section stubs below define what the drafted skill will contain. Not yet drafted.

One-paragraph purpose: drive a hospitality plan from 2D to a sell-the-idea render, keeping
the human in the loop at each stage hand-off.

## What this system is NOT
- Not a spec/compliance tool. Renders sell the concept; they do not certify it.
- Not a SketchUp tutorial. SketchUp mechanics come from the Trimble baseline skills.

## Trigger phrases → stage routing
- "turn this plan into a render" → run full pipeline
- "just model it" → stop after `modelling-hospitality-plans`
- "render this view" / "I already have a view" → jump to `rendering-with-nano-banana`

## Authority hierarchy
[Stub] Trimble baseline skills (SketchUp mechanics) > suite knowledge (hospitality domain)
> jurisdiction defaults. Research doc is conceptual only.

## The four-stage pipeline
[Stub] intake → model → render-prep → render. Define inputs/outputs and the hand-off
artifact at each boundary (cleaned model, line-work export, final render).

## Pre-flight
[Stub] Before first `build_model`: call Trimble `list_skills`, `read_skill` every baseline,
and the relevant contextual skills (part-boundaries for openings, scenes for multi-view).

## Examples
[Stub] (1) full DWG run; (2) express sketch → render lane.

## Troubleshooting
[Stub] Wrong stage entered; missing MCP; geometry not manifold; render hallucination.
